package Vista;

import Vista.*;

public class Ejecutador {

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {new SistemaVentasGUI().setVisible(true);});
    }
}
